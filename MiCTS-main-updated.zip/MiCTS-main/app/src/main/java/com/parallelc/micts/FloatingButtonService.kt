package com.parallelc.micts

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.ImageView
import androidx.core.app.NotificationCompat
import com.parallelc.micts.config.AppConfig
import com.parallelc.micts.ui.activity.SettingsActivity
import com.parallelc.micts.ui.activity.triggerFromService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Draws a draggable button above all apps. Tap = trigger Circle to Search.
 */
class FloatingButtonService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var triggerJob: Job? = null
    private lateinit var wm: WindowManager
    private var button: ImageView? = null
    private lateinit var params: WindowManager.LayoutParams

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (button == null) addButton()
        return START_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, getString(R.string.floating_button), NotificationManager.IMPORTANCE_MIN)
            )
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, SettingsActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_tile_service)
            .setContentTitle(getString(R.string.floating_button_running))
            .setContentIntent(open)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun addButton() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val density = resources.displayMetrics.density
        val sizePx = (52 * density).toInt()
        val padPx = (12 * density).toInt()

        val view = ImageView(this).apply {
            setImageResource(R.drawable.ic_tile_service)
            setPadding(padPx, padPx, padPx, padPx)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xCC202124.toInt())
            }
            elevation = 6 * density
            alpha = 0.85f
            contentDescription = getString(R.string.tile_label)
        }

        val prefs = getSharedPreferences(AppConfig.CONFIG_NAME, MODE_PRIVATE)
        val dm = resources.displayMetrics
        val savedX = prefs.getInt(AppConfig.KEY_FLOATING_X, -1)
        val savedY = prefs.getInt(AppConfig.KEY_FLOATING_Y, -1)

        params = WindowManager.LayoutParams(
            sizePx, sizePx,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = if (savedX >= 0) savedX else dm.widthPixels - sizePx
            y = if (savedY >= 0) savedY else dm.heightPixels / 3
        }

        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop
        var downRawX = 0f
        var downRawY = 0f
        var startX = 0
        var startY = 0
        var dragging = false

        view.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX
                    downRawY = event.rawY
                    startX = params.x
                    startY = params.y
                    dragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downRawX
                    val dy = event.rawY - downRawY
                    if (!dragging && (dx * dx + dy * dy) > touchSlop * touchSlop) dragging = true
                    if (dragging) {
                        val m = resources.displayMetrics
                        params.x = (startX + dx).toInt().coerceIn(0, m.widthPixels - sizePx)
                        params.y = (startY + dy).toInt().coerceIn(0, m.heightPixels - sizePx)
                        runCatching { wm.updateViewLayout(v, params) }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (dragging) {
                        // Snap to the nearest horizontal edge and remember the position.
                        val m = resources.displayMetrics
                        params.x = if (params.x + sizePx / 2 < m.widthPixels / 2) 0 else m.widthPixels - sizePx
                        runCatching { wm.updateViewLayout(v, params) }
                        prefs.edit().putInt(AppConfig.KEY_FLOATING_X, params.x)
                            .putInt(AppConfig.KEY_FLOATING_Y, params.y).apply()
                    } else {
                        v.performClick()
                        onTap(v)
                    }
                    true
                }
                else -> false
            }
        }

        runCatching { wm.addView(view, params) }.onSuccess { button = view }.onFailure { stopSelf() }
    }

    private fun onTap(v: View) {
        if (triggerJob?.isActive == true) return
        val service = TriggerAccessibilityService.instance
        if (service != null && service.isCtsOpen()) {
            // Second tap: close Circle to Search.
            triggerJob = scope.launch { service.closeCts() }
            return
        }
        triggerJob = scope.launch {
            val translate = getSharedPreferences(AppConfig.CONFIG_NAME, MODE_PRIVATE)
                .getBoolean(AppConfig.KEY_FLOATING_TRANSLATE, false)
            triggerFromService(
                this@FloatingButtonService,
                translate = translate,
                onBeforeTrigger = { v.visibility = View.INVISIBLE },
                onAfterTrigger = { v.visibility = View.VISIBLE }
            )
        }
    }

    override fun onDestroy() {
        button?.let { runCatching { wm.removeView(it) } }
        button = null
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL_ID = "floating_button"
        private const val NOTIFICATION_ID = 1001

        fun start(context: Context) {
            val intent = Intent(context, FloatingButtonService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent)
            else context.startService(intent)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, FloatingButtonService::class.java))
        }
    }
}
