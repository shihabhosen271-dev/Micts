package com.parallelc.micts

import android.accessibilityservice.AccessibilityButtonController
import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.parallelc.micts.ui.activity.triggerFromService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Lets the user launch MiCTS from Android's Accessibility Button
 * (navigation-bar button, or the floating accessibility button).
 */
class TriggerAccessibilityService : AccessibilityService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var job: Job? = null
    private var controller: AccessibilityButtonController? = null

    private val callback = object : AccessibilityButtonController.AccessibilityButtonCallback() {
        override fun onClicked(controller: AccessibilityButtonController) {
            if (job?.isActive == true) return
            job = scope.launch { triggerFromService(this@TriggerAccessibilityService) }
        }
    }

    /**
     * After Circle to Search opens, press its "Translate" button so the whole
     * screen is translated. Only looks at Google app nodes, retries for ~5 s.
     */
    suspend fun clickTranslate(): Boolean {
        repeat(20) {
            val roots = buildList {
                runCatching { windows.forEach { w -> w.root?.let { add(it) } } }
                rootInActiveWindow?.let { add(it) }
            }
            for (root in roots) {
                if (root.packageName?.toString() == GOOGLE_APP && findAndClick(root)) return true
            }
            delay(250L)
        }
        return false
    }

    /** True while the Google app (Circle to Search) has a window on screen. */
    fun isCtsOpen(): Boolean = runCatching {
        windows.any { it.root?.packageName?.toString() == GOOGLE_APP }
    }.getOrDefault(false)

    /** Close Circle to Search by pressing Back (up to 3 times, in case a sub-screen is open). */
    suspend fun closeCts() {
        repeat(3) {
            performGlobalAction(GLOBAL_ACTION_BACK)
            delay(350L)
            if (!isCtsOpen()) return
        }
    }

    private fun findAndClick(root: AccessibilityNodeInfo): Boolean {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        while (queue.isNotEmpty()) {
            val node = queue.removeFirst()
            val label = (node.contentDescription?.toString() ?: node.text?.toString() ?: "").lowercase()
            if (label.isNotEmpty() && TRANSLATE_WORDS.any { label.contains(it) }) {
                var target: AccessibilityNodeInfo? = node
                var depth = 0
                while (target != null && !target.isClickable && depth < 4) {
                    target = target.parent
                    depth++
                }
                if (target != null && target.isClickable && target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    return true
                }
            }
            for (i in 0 until node.childCount) node.getChild(i)?.let { queue.add(it) }
        }
        return false
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        controller = accessibilityButtonController.also {
            it.registerAccessibilityButtonCallback(callback)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        controller?.unregisterAccessibilityButtonCallback(callback)
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        @Volatile
        var instance: TriggerAccessibilityService? = null
        private const val GOOGLE_APP = "com.google.android.googlequicksearchbox"
        private val TRANSLATE_WORDS = listOf("translate", "অনুবাদ")
    }
}
